# favorite_color = "pink"
# print(favorite_color) #//pink
# print(id(favorite_color))
# favorite_color = "blue"
# print(favorite_color) #//blue
# print(id(favorite_color))
# favorite_color = "pink"
# print(favorite_color) #//pink
# print(id(favorite_color))

# strings, numbers , primitive data types
# immutable 
# means that the value of the address cannot change

# city = "New York"
# friend_city = city
# print("city", city) #"New York"
# print("friend_city", friend_city) #"New York"


# age = 12
# my_age = 12

# print(id(age)) #address
# print(id(my_age)) #address

# age = 12
# my_age = 12

# print(id(age)) #address
# print(id(my_age)) #address

# city = "New York"
# friend_city = city
# print("city", city) #"New York"
# print("friend_city", friend_city) #"New York"

# print(id(city)) #address
# print(id(friend_city)) #address

# city = "Paris"
# print("city", city) #"Paris"
# print("friend_city", friend_city) #"New York"