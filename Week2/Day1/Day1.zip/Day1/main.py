# print("Hello World")
# method used to display some value

# assigning a value to the variable
# declaring a variable and assigning a value
pet_animal = "dog"

# hardcoding the favorite pet
# sentence = "My favorite pet is a dog"
sentence = "My favorite pet is a " + pet_animal

# print(sentence)

# integer
# year = 2023

# concatenate
# convert the integer into a string
# sentence_two = str(year) + " is the current year"

# next_year = year + 1

# print(sentence_two)
# print("NEXT YEAR", next_year)

year = 2023
age = 19
city = "Tel Aviv"

# sentence_two = str(year) + " is the current year , I'm " + str(age) + " years old. I live in " + city
# string formatting
sentence_three = f"{year} is the current year, I'm {age} years old, I live in {city}"
print(sentence_three)