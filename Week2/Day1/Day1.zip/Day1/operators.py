Microsoft Windows [Version 10.0.19045.3324]
(c) Microsoft Corporation. All rights reserved.

C:\Users\lise9>python
Python 3.11.3 (tags/v3.11.3:f3909b8, Apr  4 2023, 23:49:59) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license" for more information.
>>> 2 + 3
5
>>> 2 - 1
1
>>> 2*2
4
>>> 5/2
2.5
>>> type(2)
<class 'int'>
>>> "hello"
'hello'
>>> type("hello")
<class 'str'>
>>> type("2")
<class 'str'>
>>> "hello" + " students"
'hello students'
>>> "hello"*3
'hellohellohello'
>>> "2" * 2
'22'
>>> int("2") * 3
6
>>> True
True
>>> False
False
>>> 2 == 3
False
>>> 3 > 2
True
>>> True == 1
True
>>> False == 0
True
>>> True + 4
5
>>> True + 4
5
>>>

>>> "hello"
'hello'
>>> 12
12
>>> 12.4
12.4
>>> type(12.4)
<class 'float'>
>>> int(12.45)
12